<?php
/*
Plugin Name: Woo Aramex Shipping
Plugin URI: http://woothemes.com/woocommerce
Description: Aramex shipping API Integration.
Version: 1.0.0
Author: Mohneesh Bhargava
Author URI: http://computerware.in
*/
 
/**
 * Check if WooCommerce is active
 */
define('SDURL', WP_PLUGIN_URL."/".dirname( plugin_basename( __FILE__ ) ) );
 
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
 
	function aramex_shipping_method_init() {
		if ( ! class_exists( 'WC_Aramex_Shipping_Method' ) ) {
			class WC_Aramex_Shipping_Method extends WC_Shipping_Method {
				/**
				 * Constructor for your shipping class
				 *
				 * @access public
				 * @return void
				 */
				public function __construct() {
					global $woocommerce;
					
					$this->id                 = 'armex_shipping_method'; // Id for your shipping method. Should be uunique.
					$this->method_title       = __( 'Armex Shipping Method' );  // Title shown in admin
					$this->method_description = __( 'Description of your shipping method' ); // Description shown in admin
 
					$this->enabled            = "yes"; // This can be added as an setting but for this example its forced enabled
					$this->title              = "Aramex Shipping Method"; // This can be added as an setting but for this example its forced.
					$this->init();
			
				}
 
				/**
				 * Init your settings
				 *
				 * @access public
				 * @return void
				 */
				function init() {
					// Load the settings API
					$this->init_form_fields(); // This is part of the settings API. Override the method to add your own settings
					$this->init_settings(); // This is part of the settings API. Loads settings you previously init.
					
					$this->AccountNumber	= $this->settings['AccountNumber'];
					$this->AccountPin		= $this->settings['AccountPin'];
					$this->UserName      	= $this->settings['UserName'];
					$this->Password			= $this->settings['Password'];
					$this->fee				= $this->settings['fee'];
					// Save settings in admin if you have any defined
					
					add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
					add_action('woocommerce_checkout_order_processed', array(&$this, 'purchase_order' ));	
				}
				
				function getTrackingResult(){
					$pathTrack 	= plugin_dir_path( __FILE__ ).'shipments-tracking-api-wsdl.wsdl';
					
					
					$soapClientTrack = new SoapClient($pathTrack);
					//echo '<pre>';
					//print_r($soapClient->__getFunctions());
					
					
			
					$params2 = array(
						'ClientInfo'  		=> array(
											'AccountCountryCode'	=> 'IN',
											'AccountEntity'		 	=> 'BOM',
											'AccountNumber'		 	=> '36670436',
											'AccountPin'		 	=> '443543',
											'UserName'			 	=> 'testingapi@aramex.com',
											'Password'			 	=> 'R123456789$r',
											'Version'			 	=> 'v1.0'
										),

						'Transaction' 			=> array(
													'Reference1'	=> '001' 
												),
						'Shipments'				=> array(
													'3702102014'
												)
					);
					
					// calling the method and printing results
					try {
						$auth_call2 = $soapClientTrack->TrackShipments($params2);
						//echo '<pre>';
						//echo "sfasf";
						//print_r($auth_call2);
						//die();
					} catch (SoapFault $fault) {
						die('Error : ' . $fault->faultstring);
					}
				}	
				
			function init_form_fields(){
				global $woocommerce;
					$this->form_fields = array(
					'enabled' => array(
						'title'		=> __('Enable/Disable', 'aramex'),
						'type'		=> 'checkbox',
						'label'		=> __('Enable Aramex', 'aramex'),
						'default'	=> 'no'
					),
					'testmode' => array(
						'title'		=> __('Test Mode', 'aramex'),
						'type'		=> 'checkbox',
						'label'		=> __('Enable test mode', 'aramex'),
						'default'	=> 'no'
					),
					'title' => array(
						'title'			=> __('Method title', 'aramex'),
						'type'			=> 'text',
						'description'	=> __('Enter the title of the shipping method.', 'aramex'),
						'default'		=> __('Aramex', 'aramex')
					),
					'api'           => array(
						'title'           => __( 'API Settings', 'aramex' ),
						'type'            => 'title',
						'description'     => __( 'Your API access details', 'aramex' )
					),
					'AccountNumber' => array(
						'title'			=> __('Account Number', 'aramex'),
						'type'			=> 'text',
						'css'			=> 'width: 250px;',
						'description'	=> __('Your Aramex Account Number', 'aramex'),
						'default'		=> ''
					),
					'AccountPin' => array(
						'title'			=> __('Account Pin', 'aramex'),
						'type'			=> 'text',
						'css'			=> 'width: 250px;',
						'description'	=> __('Your Aramex Account Pin', 'aramex'),
						'default'		=> ''
					),
					'UserName' => array(
						'title'			=> __('Username', 'aramex'),
						'type'			=> 'text',
						'css'			=> 'width: 250px;',
						'description'	=> __('Your Aramex username', 'aramex'),
						'default'		=> ''
					),
					'Password' => array(
						'title'			=> __('Password', 'aramex'),
						'type'			=> 'text',
						'css'			=> 'width: 250px;',
						'description'	=> __('Your Aramex password', 'aramex'),
						'default'		=> ''
					),
					'fee' => array(
						'title'			=> __('Handling Fee', 'aramex'),
						'type'			=> 'text',
						'description'	=> __('Fee excluding tax. Enter an amount, e.g. 2.50, or a percentage, e.g. 5%. Leave blank for no fee.', 'aramex'),
						'default'		=> '0'
					)
				);
				}
				
				/**
				 * calculate_shipping function.
				 *
				 * @access public
				 * @param mixed $package
				 * @return void
				 */
				public function calculate_shipping( $package ) {
					$rate = array(
						'id' => $this->id,
						'label' => $this->title,
						'cost' => $this->fee,
						'calc_tax' => 'per_item'
					);
 
					// Register the rate
					$this->add_rate( $rate );
				}
				
				public function purchase_order($order_id)
				{ 
					try
					{
					   global $woocommerce;

					  $chosen_shipping_methods = $woocommerce->session->get( 'chosen_shipping_methods' );
					  error_log(var_export($chosen_shipping_methods,1));
					  $order        = &new WC_Order($order_id);
					  $shipping     = $order->get_shipping_address();
					
					  $method = $order->get_shipping_methods();
					  $method = array_values($method);
					  $shipping_method = $method[0]['method_id'];
					  $ship_arr = explode('|',$shipping_method);
					  //print_r($ship_arr);exit;
					  
					  $path 	= plugin_dir_path( __FILE__ ).'shipping-services-api-wsdl.wsdl';
					  $soapClient = new SoapClient($path);
					  
					  $params = array(
						'Shipments' => array(
							'Shipment' => array(
								'Shipper' => array(
											'Reference1' 	=> 'Ref 111111',
											'Reference2' 	=> 'Ref 222222',
											'AccountNumber' => '36670436',
											'PartyAddress'	=> array(
												'Line1'					=> 'Mecca St',
												'Line2' 				=> '',
												'Line3' 				=> '',
												'City'					=> '',
												'StateOrProvinceCode'	=> '',
												'PostCode'				=> '400093',
												'CountryCode'			=> 'IN'
											),
											'Contact'		=> array(
												'Department'			=> '',
												'PersonName'			=> 'Michael',
												'Title'					=> '',
												'CompanyName'			=> 'Kanabis',
												'PhoneNumber1'			=> '5555555',
												'PhoneNumber1Ext'		=> '125',
												'PhoneNumber2'			=> '',
												'PhoneNumber2Ext'		=> '',
												'FaxNumber'				=> '',
												'CellPhone'				=> '07777777',
												'EmailAddress'			=> 'michael@aramex.com',
												'Type'					=> ''
											),
								),
															
								'Consignee'	=> array(
											'Reference1'	=> 'Ref 333333',
											'Reference2'	=> 'Ref 444444',
											'AccountNumber' => '',
											'PartyAddress'	=> array(
												'Line1'					=> '15 ABC St',
												'Line2'					=> '',
												'Line3'					=> '',
												'City'					=> '',
												'StateOrProvinceCode'	=> '',
												'PostCode'				=> '110016',
												'CountryCode'			=> 'IN'
											),
											
											'Contact'		=> array(
												'Department'			=> '',
												'PersonName'			=> 'Mazen',
												'Title'					=> '',
												'CompanyName'			=> 'Aramex',
												'PhoneNumber1'			=> '6666666',
												'PhoneNumber1Ext'		=> '155',
												'PhoneNumber2'			=> '',
												'PhoneNumber2Ext'		=> '',
												'FaxNumber'				=> '',
												'CellPhone'				=> '9652356253',
												'EmailAddress'			=> 'mazen@aramex.com',
												'Type'					=> ''
											),
								),
									
								'ThirdParty' => array(
												'Reference1' 	=> '',
												'Reference2' 	=> '',
												'AccountNumber' => '',
												'PartyAddress'	=> array(
													'Line1'					=> '',
													'Line2'					=> '',
													'Line3'					=> '',
													'City'					=> '',
													'StateOrProvinceCode'	=> '',
													'PostCode'				=> '',
													'CountryCode'			=> ''
												),
												'Contact'		=> array(
													'Department'			=> '',
													'PersonName'			=> '',
													'Title'					=> '',
													'CompanyName'			=> '',
													'PhoneNumber1'			=> '',
													'PhoneNumber1Ext'		=> '',
													'PhoneNumber2'			=> '',
													'PhoneNumber2Ext'		=> '',
													'FaxNumber'				=> '',
													'CellPhone'				=> '',
													'EmailAddress'			=> '',
													'Type'					=> ''							
												),
								),
									
									'Reference1' 				=> 'Shpt 0001',
									'Reference2' 				=> '',
									'Reference3' 				=> '',
									'ForeignHAWB'				=> '',
									'TransportType'				=> 0,
									'ShippingDateTime' 			=> time(),
									'DueDate'					=> time(),
									'PickupLocation'			=> 'Reception',
									'PickupGUID'				=> '',
									'Comments'					=> 'Shpt 0001',
									'AccountingInstrcutions' 	=> '',
									'OperationsInstructions'	=> '',
									
									'Details' => array(
													'Dimensions' => array(
														'Length'				=> 10,
														'Width'					=> 10,
														'Height'				=> 10,
														'Unit'					=> 'cm',
														
													),
													
													'ActualWeight' => array(
														'Value'					=> 0.5,
														'Unit'					=> 'Kg'
													),
													
													'ProductGroup' 			=> 'EXP',
													'ProductType'			=> 'PDX',
													'PaymentType'			=> 'P',
													'PaymentOptions' 		=> '',
													'Services'				=> '',
													'NumberOfPieces'		=> 1,
													'DescriptionOfGoods' 	=> 'Docs',
													'GoodsOriginCountry' 	=> 'IN',
													
													'CashOnDeliveryAmount' 	=> array(
														'Value'					=> 0,
														'CurrencyCode'			=> 'INR'
													),
													
													/*'InsuranceAmount'		=> array(
														'Value'					=> 0,
														'CurrencyCode'			=> 'INR'
													),*/
													
													'CollectAmount'			=> array(
														'Value'					=> 0,
														'CurrencyCode'			=> 'INR'
													),
													
													'CashAdditionalAmount'	=> array(
														'Value'					=> 0,
														'CurrencyCode'			=> 'INR'							
													),
													
													'CashAdditionalAmountDescription' => '',
													
													'CustomsValueAmount' => array(
														'Value'					=> 0,
														'CurrencyCode'			=> 'INR'								
													),
										
													'Items' 				=> array(
														
													)
										),
								),
						),
						
							'ClientInfo'  			=> array(
														'AccountCountryCode'	=> 'IN',
														'AccountEntity'		 	=> 'BOM',
														'AccountNumber'		 	=> '36670436',
														'AccountPin'		 	=> '443543',
														'UserName'			 	=> 'testingapi@aramex.com',
														'Password'			 	=> 'R123456789$r',
														'Version'			 	=> 'v1.0
	'
													),

							'Transaction' 			=> array(
														'Reference1'			=> '001',
														'Reference2'			=> '', 
														'Reference3'			=> '', 
														'Reference4'			=> '', 
														'Reference5'			=> '',									
													),
							'LabelInfo'				=> array(
														'ReportID' 				=> 9201,
														'ReportType'			=> 'URL',
							),
					);
					
					$params['Shipments']['Shipment']['Details']['Items'][] = array(
						'PackageType' 	=> 'Box',
						'Quantity'		=> 1,
						'Weight'		=> array(
								'Value'		=> 0.5,
								'Unit'		=> 'Kg',		
						),
						'Comments'		=> 'Docs',
						'Reference'		=> ''
					);
					
						//print_r($params['Shipments']['Shipment']['Details']['Items']);exit;
						try {
							$auth_call = $soapClient->CreateShipments($params);
							//echo '<pre>';
							//echo "sfasf";
							//print_r($auth_call->Shipments);
							//die();
						} catch (SoapFault $fault) {
							die('Error : ' . $fault->faultstring);
						}
			
					}
					catch(Exception $e)
					{
					  //mail('seanvoss@gmail.com', 'Error from WordPress', var_export($e,1));
					}
				}
				


				
			}
		}
	}
 
	add_action( 'woocommerce_shipping_init', 'aramex_shipping_method_init' );
 
	function add_aramex_shipping_method( $methods ) {
		$methods[] = 'WC_Aramex_Shipping_Method';
		return $methods;
	}
	add_filter( 'woocommerce_shipping_methods', 'add_aramex_shipping_method' );

	
/**
 * Display Metabox Shipment Tracking on order admin page
**/

	add_action( 'add_meta_boxes', 'woocommerce_metaboxes' );
	add_action( 'woocommerce_order_items_table','track_page_shipping_details' );
	add_action( 'woocommerce_process_shop_order_meta', 'woocommerce_process_shop_ordermeta', 5, 2 );
	add_action( 'woocommerce_email_before_order_table', 'email_shipping_details' );
	add_action( 'manage_edit-shop_order_columns', 'add_shipping_column',11);
	add_action( 'manage_shop_order_posts_custom_column', 'add_shipping_column_details');
	
/**
 * Add fields to the metabox
 **/
	function add_shipping_column_details($column){ 
			global $post, $woocommerce, $the_order;
			
			if ( empty( $the_order ) || $the_order->id != $post->ID )
				$the_order = new WC_Order( $post->ID );
				 
			switch ( $column ) { 	
				case "tracking_number" :
					$order_meta = get_post_custom( $the_order->id );
								
					for ($i=0; $i<=4; $i++)
				  	{
						if($i == 0){
							if(isset($order_meta['_order_trackno']) && isset($order_meta['_order_trackurl'])){
					  			admin_shipping_details( $order_meta['_order_trackno'], $order_meta['_order_trackurl'] , $order);
							}
						}else{
							if(isset($order_meta['_order_trackno'.$i]) && isset($order_meta['_order_trackurl'.$i])){
					  			admin_shipping_details($order_meta['_order_trackno'.$i] , $order_meta['_order_trackurl'.$i] , $order);
							}					
						}
				  	}
				break;	
			}
		}
		function add_shipping_column($columns){ 
			$columns["tracking_number"] 	= __('Tracking Number', 'aramex');
			return $columns;	
		}
		
	function woocommerce_process_shop_ordermeta( $post_id, $post ) { 
		global $wpdb, $woocommerce;
		$woocommerce_errors = array();
		
		add_post_meta( $post_id, '_order_key', uniqid('order_') );
		update_post_meta( $post_id, '_order_trackno', stripslashes( $_POST['_order_trackno'] ));
		update_post_meta( $post_id, '_order_trackurl', stripslashes( $_POST['_order_trackurl'] ));
	}
		
	function woocommerce_metaboxes() {
		add_meta_box( 'woocommerce-order-my-custom', __('Shipping Details', 'aramex'), 'woocommerce_order_shippingdetails', 
			'shop_order', 'side', 'high');
	}
		
	function woocommerce_order_shippingdetails($post) {
			$data = get_post_custom( $post->ID );
			$options = get_option( 'woo_ship_options' );
			?>
			<div id="sdetails">
				<ul class="totals">
					<li>
						<label><?php _e('Tracking Number:', 'aramex'); ?></label>
						<br />
						<input type="text" id="_order_trackno" name="_order_trackno" placeholder="Enter Tracking No" value="<?php if (isset($data['_order_trackno'][0])) echo $data['_order_trackno'][0]; ?>" class="first" />
					</li>		
					<li>
						<label><?php _e('Shipping Company:', 'aramex'); ?></label><br />
						<select id="_order_trackurl" name="_order_trackurl" onselect="javascript:toggle();" onclick="javascript:toggle();" >
							<option value="NOTRACK" <?php if ( isset($data['_order_trackurl'][0]) && $data['_order_trackurl'][0] == 'NOTRACK') {
								echo 'selected="selected"';
							} ?>><?php _e('No Tracking', 'aramex'); ?></option>
							<?php shipping_details_options( $data, $options, '' ); ?>
						</select>
					</li>
					<li id="shownzcourierinfo" style="display: none">
					<h4><?php _e('Enter the Tracking Number as', 'aramex'); ?> <b style="color:red;">LH-14148561</b>.</h4>
					<img src="<?php echo SDURL.'/img/lab1.jpg'; ?>"/>
					</li>
					<li id="showpostnllinfo" style="display: none">
					<h4><?php _e('Enter the Tracking Number as', 'aramex'); ?> <br><b style="color:red;"><?php _e('TrackingNo-PostalCode', 'aramex'); ?></b>.</h4>
					</li>
					<li id="showapcovernight" style="display: none">
					<h4><?php _e('Enter the Tracking Number as', 'aramex'); ?> <br><b style="color:red;"><?php _e('PostalCode-TrackingNo', 'aramex'); ?></b>.</h4>
					</li>
				</ul>
			</div>
			<div class="clear"></div>
			<?php 
		}
	
		function shipping_details_options($data, $options, $part){ 
			if ($part == '0' || $part == '' ) {
				$part = '';
			}
			$shipping_companies = get_shipping_list();
			foreach( $shipping_companies as $k => $v ){
				if (isset($options[$k]) == '1') {
					echo '<option value="'.$k.'" ';
					if (isset($data['_order_trackurl'.$part][0]) && $data['_order_trackurl'.$part][0] == $k) {
						echo 'selected="selected"';
					}
					echo '>'.$v.'</option>'; 
				}
			}
		}
		
		function track_page_shipping_details( $order ){	
			$order_meta = get_post_custom( $order->id );
			for ($i=0; $i<=4; $i++)
		  	{
				if($i == 0){
					if(isset($order_meta['_order_trackno']) && isset($order_meta['_order_trackurl'])){
			  			shipping_details( $order_meta['_order_trackno'], $order_meta['_order_trackurl'] , $order);
					}
				}else{
					if(isset($order_meta['_order_trackno'.$i]) && isset($order_meta['_order_trackurl'.$i])){
			  			shipping_details($order_meta['_order_trackno'.$i] , $order_meta['_order_trackurl'.$i] , $order);
					}					
				}
		  	}
		}
		
		function shipping_details($trackno , $trackurl , $order){
			$options = get_option( 'woo_ship_options' );
			$shipping_companies = get_shipping_list();
			if ($trackurl[0] == 'ARAMEX'){
				$urltrack = 'http://www.aramex.com/track_results_multiple.aspx?ShipmentNumber='.$trackno[0];
			}
			if ($trackno[0] != null && $trackurl[0] != null && $trackurl[0] != 'NOTRACK' ) { ?>
				<h3><?php _e('Your Order has been shipped via', 'aramex'); ?> <?php echo $shipping_companies[$trackurl[0]]; ?>.</h3>
				<?php if ($trackurl[0] == 'POSTNLL'){?>
				<STRONG><?php _e('Tracking #', 'aramex'); ?> </STRONG><?php echo $track[0]; ?><br/>
				<STRONG><?php _e('Postal Code' , 'aramex');?> </STRONG><?php echo $track[1]; ?>
				<?php } else if ($trackurl[0] == 'APCOVERNIGHT'){?>
				<STRONG><?php _e('Consignment #', 'aramex'); ?> </STRONG><?php echo $track[1]; ?><br/>
				<STRONG><?php _e('Postal Code' , 'aramex');?> </STRONG><?php echo $track[0]; ?>
				<?php } else { ?>
				<STRONG><?php _e('Tracking #', 'aramex'); ?></STRONG><?php echo $trackno[0]; ?>
				<?php } ?>
				<br/>
				<?php 
				$ch = __('CLICK HERE', 'aramex');
				$ch2 = __('to track your shipment.', 'aramex');
				
				if($form == 'yes'){ 
					echo $urltrack;
					?>
					<a href="#" onclick="document.forms['<?php echo $trackurl[0]; ?>'].submit();"><STRONG><?php echo $ch; ?></STRONG></a> <?php echo $ch2; ?>
				<?php }else{ ?>
				<a href="<?php echo $urltrack; ?>" target="_blank" ><STRONG><?php echo $ch; ?></STRONG></a> <?php echo $ch2; ?>
				<?php } ?>
				<br/><br/>	
			<?php } 
		}
		
		function admin_shipping_details($trackno , $trackurl , $order){
			$options = get_option( 'woo_ship_options' );
			$shipping_companies = get_shipping_list();
			if ($trackurl[0] == 'ARAMEX'){
				$urltrack = 'http://www.aramex.com/track_results_multiple.aspx?ShipmentNumber='.$trackno[0];
			}
			if ($trackno[0] != null && $trackurl[0] != null && $trackurl[0] != 'NOTRACK' ) { ?>
				<STRONG><?php echo $shipping_companies[$trackurl[0]]; ?></STRONG><br/>
				<?php if ($trackurl[0] == 'POSTNLL'){?>
				<STRONG><?php _e('Tracking #', 'aramex'); ?> </STRONG><?php echo $track[0]; ?><br/>
				<STRONG><?php _e('Postal Code' , 'aramex');?> </STRONG><?php echo $track[1]; ?>
				<?php } else if ($trackurl[0] == 'APCOVERNIGHT'){?>
				<STRONG><?php _e('Consignment #', 'aramex'); ?> </STRONG><?php echo $track[1]; ?><br/>
				<STRONG><?php _e('Postal Code' , 'aramex');?> </STRONG><?php echo $track[0]; ?>
				<?php } else { ?>
				<STRONG><?php _e('Tracking #', 'aramex'); ?></STRONG><?php echo $trackno[0]; ?>
				<?php } ?>
				<br/><br/>
			<?php } 
		}
		
		function email_shipping_details( $order ) { 
			$order_meta = get_post_custom( $order->id );
			for ($i=0; $i<=4; $i++)
		  	{
				if($i == 0){
					if(isset($order_meta['_order_trackno']) && isset($order_meta['_order_trackurl'])){
			  			shipping_details($order_meta['_order_trackno'] , $order_meta['_order_trackurl'] , $order);
					}
				}else{
					if(isset($order_meta['_order_trackno'.$i]) && isset($order_meta['_order_trackurl'.$i])){
			  			shipping_details($order_meta['_order_trackno'.$i] , $order_meta['_order_trackurl'.$i] , $order);
					}					
				}
		  	}
		}	
		
		function get_shipping_list(){
			return $shipping_companies = Array('ARAMEX' => __('Aramex', 'aramex'));
		}
	
} // is active woocommerce 